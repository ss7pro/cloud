The :mod:`nova.api.openstack.compute.contrib.volumetypes` Module
=================================================================

.. automodule:: nova.api.openstack.compute.contrib.volumetypes
  :members:
  :undoc-members:
  :show-inheritance:
