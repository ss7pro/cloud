The :mod:`nova.api.openstack.compute.versions` Module
======================================================

.. automodule:: nova.api.openstack.compute.versions
  :members:
  :undoc-members:
  :show-inheritance:
