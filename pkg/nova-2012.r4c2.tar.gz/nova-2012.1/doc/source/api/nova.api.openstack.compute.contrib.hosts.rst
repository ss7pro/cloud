The :mod:`nova.api.openstack.compute.contrib.hosts` Module
===========================================================

.. automodule:: nova.api.openstack.compute.contrib.hosts
  :members:
  :undoc-members:
  :show-inheritance:
