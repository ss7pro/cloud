The :mod:`nova.api.openstack.compute.contrib.flavorextradata` Module
=====================================================================

.. automodule:: nova.api.openstack.compute.contrib.flavorextradata
  :members:
  :undoc-members:
  :show-inheritance:
