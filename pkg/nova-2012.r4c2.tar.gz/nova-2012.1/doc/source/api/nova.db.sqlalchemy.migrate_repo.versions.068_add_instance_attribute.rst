The :mod:`nova.db.sqlalchemy.migrate_repo.versions.068_add_instance_attribute` Module
======================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.068_add_instance_attribute
  :members:
  :undoc-members:
  :show-inheritance:
