The :mod:`nova.virt.vmwareapi_conn` Module
===========================================

.. automodule:: nova.virt.vmwareapi_conn
  :members:
  :undoc-members:
  :show-inheritance:
