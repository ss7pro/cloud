The :mod:`nova.api.openstack.compute.contrib.volumes` Module
=============================================================

.. automodule:: nova.api.openstack.compute.contrib.volumes
  :members:
  :undoc-members:
  :show-inheritance:
