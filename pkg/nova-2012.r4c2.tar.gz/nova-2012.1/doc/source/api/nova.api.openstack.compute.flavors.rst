The :mod:`nova.api.openstack.compute.flavors` Module
=====================================================

.. automodule:: nova.api.openstack.compute.flavors
  :members:
  :undoc-members:
  :show-inheritance:
