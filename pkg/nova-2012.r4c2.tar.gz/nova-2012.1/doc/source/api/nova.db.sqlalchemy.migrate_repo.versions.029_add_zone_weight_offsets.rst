The :mod:`nova.db.sqlalchemy.migrate_repo.versions.029_add_zone_weight_offsets` Module
=======================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.029_add_zone_weight_offsets
  :members:
  :undoc-members:
  :show-inheritance:
