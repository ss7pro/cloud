The :mod:`nova.notifier.capacity_notifier` Module
==================================================

.. automodule:: nova.notifier.capacity_notifier
  :members:
  :undoc-members:
  :show-inheritance:
