The :mod:`nova.api.openstack.compute.contrib.users` Module
===========================================================

.. automodule:: nova.api.openstack.compute.contrib.users
  :members:
  :undoc-members:
  :show-inheritance:
