The :mod:`nova.db.sqlalchemy.migrate_repo.versions.028_add_instance_type_extra_specs` Module
=============================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.028_add_instance_type_extra_specs
  :members:
  :undoc-members:
  :show-inheritance:
