The :mod:`nova.db.sqlalchemy.migrate_repo.versions.019_add_volume_snapshot_support` Module
===========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.019_add_volume_snapshot_support
  :members:
  :undoc-members:
  :show-inheritance:
