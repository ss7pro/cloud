The :mod:`nova.rootwrap.wrapper` Module
========================================

.. automodule:: nova.rootwrap.wrapper
  :members:
  :undoc-members:
  :show-inheritance:
