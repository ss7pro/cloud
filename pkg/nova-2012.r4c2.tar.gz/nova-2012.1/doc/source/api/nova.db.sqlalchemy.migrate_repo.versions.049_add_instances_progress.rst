The :mod:`nova.db.sqlalchemy.migrate_repo.versions.049_add_instances_progress` Module
======================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.049_add_instances_progress
  :members:
  :undoc-members:
  :show-inheritance:
