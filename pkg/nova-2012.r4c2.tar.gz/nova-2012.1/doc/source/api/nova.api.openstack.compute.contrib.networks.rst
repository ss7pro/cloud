The :mod:`nova.api.openstack.compute.contrib.networks` Module
==============================================================

.. automodule:: nova.api.openstack.compute.contrib.networks
  :members:
  :undoc-members:
  :show-inheritance:
