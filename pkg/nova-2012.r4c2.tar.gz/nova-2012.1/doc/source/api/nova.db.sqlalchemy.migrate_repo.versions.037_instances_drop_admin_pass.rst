The :mod:`nova.db.sqlalchemy.migrate_repo.versions.037_instances_drop_admin_pass` Module
=========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.037_instances_drop_admin_pass
  :members:
  :undoc-members:
  :show-inheritance:
