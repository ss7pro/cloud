The :mod:`nova.api.openstack.volume.snapshots` Module
======================================================

.. automodule:: nova.api.openstack.volume.snapshots
  :members:
  :undoc-members:
  :show-inheritance:
