The :mod:`nova.notifier.api` Module
====================================

.. automodule:: nova.notifier.api
  :members:
  :undoc-members:
  :show-inheritance:
