The :mod:`nova.db.sqlalchemy.migrate_repo.versions.032_add_root_device_name` Module
====================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.032_add_root_device_name
  :members:
  :undoc-members:
  :show-inheritance:
