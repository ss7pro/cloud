The :mod:`nova.api.openstack.compute.contrib.server_start_stop` Module
=======================================================================

.. automodule:: nova.api.openstack.compute.contrib.server_start_stop
  :members:
  :undoc-members:
  :show-inheritance:
