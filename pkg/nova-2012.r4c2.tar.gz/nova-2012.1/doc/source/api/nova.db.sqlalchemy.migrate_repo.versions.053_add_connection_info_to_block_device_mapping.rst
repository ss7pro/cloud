The :mod:`nova.db.sqlalchemy.migrate_repo.versions.053_add_connection_info_to_block_device_mapping` Module
===========================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.053_add_connection_info_to_block_device_mapping
  :members:
  :undoc-members:
  :show-inheritance:
