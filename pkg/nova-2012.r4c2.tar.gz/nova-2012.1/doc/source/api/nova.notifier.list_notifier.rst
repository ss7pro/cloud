The :mod:`nova.notifier.list_notifier` Module
==============================================

.. automodule:: nova.notifier.list_notifier
  :members:
  :undoc-members:
  :show-inheritance:
