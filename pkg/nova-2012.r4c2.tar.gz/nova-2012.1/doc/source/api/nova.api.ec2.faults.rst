The :mod:`nova.api.ec2.faults` Module
======================================

.. automodule:: nova.api.ec2.faults
  :members:
  :undoc-members:
  :show-inheritance:
