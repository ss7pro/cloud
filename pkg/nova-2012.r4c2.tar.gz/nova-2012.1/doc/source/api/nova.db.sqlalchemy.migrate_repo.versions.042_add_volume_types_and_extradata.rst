The :mod:`nova.db.sqlalchemy.migrate_repo.versions.042_add_volume_types_and_extradata` Module
==============================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.042_add_volume_types_and_extradata
  :members:
  :undoc-members:
  :show-inheritance:
