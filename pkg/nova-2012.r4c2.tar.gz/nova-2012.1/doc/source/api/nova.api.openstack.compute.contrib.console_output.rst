The :mod:`nova.api.openstack.compute.contrib.console_output` Module
====================================================================

.. automodule:: nova.api.openstack.compute.contrib.console_output
  :members:
  :undoc-members:
  :show-inheritance:
