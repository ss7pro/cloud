The :mod:`nova.rpc.common` Module
==================================

.. automodule:: nova.rpc.common
  :members:
  :undoc-members:
  :show-inheritance:
