The :mod:`nova.virt.xenapi.host` Module
========================================

.. automodule:: nova.virt.xenapi.host
  :members:
  :undoc-members:
  :show-inheritance:
