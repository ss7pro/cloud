The :mod:`nova.db.sqlalchemy.migrate_repo.versions.052_kill_export_devices` Module
===================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.052_kill_export_devices
  :members:
  :undoc-members:
  :show-inheritance:
