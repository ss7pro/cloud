The :mod:`nova.db.sqlalchemy.migrate_repo.versions.016_make_quotas_key_and_value` Module
=========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.016_make_quotas_key_and_value
  :members:
  :undoc-members:
  :show-inheritance:
