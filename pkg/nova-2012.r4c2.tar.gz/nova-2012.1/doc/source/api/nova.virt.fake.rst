The :mod:`nova.virt.fake` Module
=================================

.. automodule:: nova.virt.fake
  :members:
  :undoc-members:
  :show-inheritance:
