The :mod:`nova.api.openstack.common` Module
============================================

.. automodule:: nova.api.openstack.common
  :members:
  :undoc-members:
  :show-inheritance:
