The :mod:`nova.db.sqlalchemy.migrate_repo.versions.058_rename_managed_disk` Module
===================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.058_rename_managed_disk
  :members:
  :undoc-members:
  :show-inheritance:
