The :mod:`nova.db.sqlalchemy.migrate_repo.versions.080_add_hypervisor_hostname_to_compute_nodes` Module
========================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.080_add_hypervisor_hostname_to_compute_nodes
  :members:
  :undoc-members:
  :show-inheritance:
