The :mod:`nova.api.openstack.compute.contrib.quotas` Module
============================================================

.. automodule:: nova.api.openstack.compute.contrib.quotas
  :members:
  :undoc-members:
  :show-inheritance:
