The :mod:`nova.testing.fake.rabbit` Module
===========================================

.. automodule:: nova.testing.fake.rabbit
  :members:
  :undoc-members:
  :show-inheritance:
