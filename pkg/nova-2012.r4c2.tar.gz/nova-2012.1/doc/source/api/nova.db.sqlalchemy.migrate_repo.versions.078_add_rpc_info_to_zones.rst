The :mod:`nova.db.sqlalchemy.migrate_repo.versions.078_add_rpc_info_to_zones` Module
=====================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.078_add_rpc_info_to_zones
  :members:
  :undoc-members:
  :show-inheritance:
