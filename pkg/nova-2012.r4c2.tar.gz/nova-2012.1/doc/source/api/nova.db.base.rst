The :mod:`nova.db.base` Module
===============================

.. automodule:: nova.db.base
  :members:
  :undoc-members:
  :show-inheritance:
