The :mod:`nova.api.openstack.compute.contrib.aggregates` Module
================================================================

.. automodule:: nova.api.openstack.compute.contrib.aggregates
  :members:
  :undoc-members:
  :show-inheritance:
