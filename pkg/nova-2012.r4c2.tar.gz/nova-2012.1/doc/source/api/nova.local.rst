The :mod:`nova.local` Module
=============================

.. automodule:: nova.local
  :members:
  :undoc-members:
  :show-inheritance:
