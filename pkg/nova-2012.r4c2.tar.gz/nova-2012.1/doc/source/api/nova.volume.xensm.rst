The :mod:`nova.volume.xensm` Module
====================================

.. automodule:: nova.volume.xensm
  :members:
  :undoc-members:
  :show-inheritance:
