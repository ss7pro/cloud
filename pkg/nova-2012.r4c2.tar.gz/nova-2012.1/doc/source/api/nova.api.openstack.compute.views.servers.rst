The :mod:`nova.api.openstack.compute.views.servers` Module
===========================================================

.. automodule:: nova.api.openstack.compute.views.servers
  :members:
  :undoc-members:
  :show-inheritance:
