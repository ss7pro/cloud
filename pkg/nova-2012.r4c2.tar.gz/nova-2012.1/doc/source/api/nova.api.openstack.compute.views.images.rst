The :mod:`nova.api.openstack.compute.views.images` Module
==========================================================

.. automodule:: nova.api.openstack.compute.views.images
  :members:
  :undoc-members:
  :show-inheritance:
