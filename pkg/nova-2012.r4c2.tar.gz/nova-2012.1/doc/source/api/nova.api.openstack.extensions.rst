The :mod:`nova.api.openstack.extensions` Module
================================================

.. automodule:: nova.api.openstack.extensions
  :members:
  :undoc-members:
  :show-inheritance:
