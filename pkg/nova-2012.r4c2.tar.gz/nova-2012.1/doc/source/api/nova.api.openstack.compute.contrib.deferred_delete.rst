The :mod:`nova.api.openstack.compute.contrib.deferred_delete` Module
=====================================================================

.. automodule:: nova.api.openstack.compute.contrib.deferred_delete
  :members:
  :undoc-members:
  :show-inheritance:
