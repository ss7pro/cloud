The :mod:`nova.virt.vmwareapi.fake` Module
===========================================

.. automodule:: nova.virt.vmwareapi.fake
  :members:
  :undoc-members:
  :show-inheritance:
