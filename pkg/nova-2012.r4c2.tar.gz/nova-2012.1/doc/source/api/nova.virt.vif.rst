The :mod:`nova.virt.vif` Module
================================

.. automodule:: nova.virt.vif
  :members:
  :undoc-members:
  :show-inheritance:
