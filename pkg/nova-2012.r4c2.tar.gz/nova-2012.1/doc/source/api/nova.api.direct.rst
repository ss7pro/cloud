The :mod:`nova.api.direct` Module
==================================

.. automodule:: nova.api.direct
  :members:
  :undoc-members:
  :show-inheritance:
