The :mod:`nova.api.openstack.compute.consoles` Module
======================================================

.. automodule:: nova.api.openstack.compute.consoles
  :members:
  :undoc-members:
  :show-inheritance:
