The :mod:`nova.db.sqlalchemy.migrate_repo.versions.001_austin` Module
======================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.001_austin
  :members:
  :undoc-members:
  :show-inheritance:
