The :mod:`nova.compute.instance_types` Module
==============================================

.. automodule:: nova.compute.instance_types
  :members:
  :undoc-members:
  :show-inheritance:
