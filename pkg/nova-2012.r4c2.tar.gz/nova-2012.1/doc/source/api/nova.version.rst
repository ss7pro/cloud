The :mod:`nova.version` Module
===============================

.. automodule:: nova.version
  :members:
  :undoc-members:
  :show-inheritance:
