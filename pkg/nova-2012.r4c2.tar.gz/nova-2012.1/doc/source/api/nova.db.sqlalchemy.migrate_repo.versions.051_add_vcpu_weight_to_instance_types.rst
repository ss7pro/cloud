The :mod:`nova.db.sqlalchemy.migrate_repo.versions.051_add_vcpu_weight_to_instance_types` Module
=================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.051_add_vcpu_weight_to_instance_types
  :members:
  :undoc-members:
  :show-inheritance:
