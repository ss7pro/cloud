The :mod:`nova.network.quantum.client` Module
==============================================

.. automodule:: nova.network.quantum.client
  :members:
  :undoc-members:
  :show-inheritance:
