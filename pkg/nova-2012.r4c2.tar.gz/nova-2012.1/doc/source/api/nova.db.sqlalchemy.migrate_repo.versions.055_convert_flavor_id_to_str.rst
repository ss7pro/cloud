The :mod:`nova.db.sqlalchemy.migrate_repo.versions.055_convert_flavor_id_to_str` Module
========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.055_convert_flavor_id_to_str
  :members:
  :undoc-members:
  :show-inheritance:
