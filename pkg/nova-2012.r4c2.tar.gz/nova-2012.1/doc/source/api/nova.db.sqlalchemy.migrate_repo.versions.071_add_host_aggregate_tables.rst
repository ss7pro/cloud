The :mod:`nova.db.sqlalchemy.migrate_repo.versions.071_add_host_aggregate_tables` Module
=========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.071_add_host_aggregate_tables
  :members:
  :undoc-members:
  :show-inheritance:
