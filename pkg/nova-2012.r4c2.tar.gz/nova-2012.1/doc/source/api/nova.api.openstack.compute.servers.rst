The :mod:`nova.api.openstack.compute.servers` Module
=====================================================

.. automodule:: nova.api.openstack.compute.servers
  :members:
  :undoc-members:
  :show-inheritance:
