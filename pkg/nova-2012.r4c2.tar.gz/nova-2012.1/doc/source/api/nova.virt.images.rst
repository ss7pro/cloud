The :mod:`nova.virt.images` Module
===================================

.. automodule:: nova.virt.images
  :members:
  :undoc-members:
  :show-inheritance:
