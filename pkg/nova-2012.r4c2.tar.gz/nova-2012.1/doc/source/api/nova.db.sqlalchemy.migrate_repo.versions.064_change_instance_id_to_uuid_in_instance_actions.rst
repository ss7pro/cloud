The :mod:`nova.db.sqlalchemy.migrate_repo.versions.064_change_instance_id_to_uuid_in_instance_actions` Module
==============================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.064_change_instance_id_to_uuid_in_instance_actions
  :members:
  :undoc-members:
  :show-inheritance:
