The :mod:`nova.db.sqlalchemy.migrate_repo.versions.057_add_sm_driver_tables` Module
====================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.057_add_sm_driver_tables
  :members:
  :undoc-members:
  :show-inheritance:
