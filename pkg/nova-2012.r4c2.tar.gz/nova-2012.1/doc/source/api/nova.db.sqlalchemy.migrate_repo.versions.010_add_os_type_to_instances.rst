The :mod:`nova.db.sqlalchemy.migrate_repo.versions.010_add_os_type_to_instances` Module
========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.010_add_os_type_to_instances
  :members:
  :undoc-members:
  :show-inheritance:
