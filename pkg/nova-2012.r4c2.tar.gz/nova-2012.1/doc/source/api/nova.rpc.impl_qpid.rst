The :mod:`nova.rpc.impl_qpid` Module
=====================================

.. automodule:: nova.rpc.impl_qpid
  :members:
  :undoc-members:
  :show-inheritance:
