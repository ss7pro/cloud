The :mod:`nova.api.openstack.volume.extensions` Module
=======================================================

.. automodule:: nova.api.openstack.volume.extensions
  :members:
  :undoc-members:
  :show-inheritance:
