The :mod:`nova.network.quantum.melange_connection` Module
==========================================================

.. automodule:: nova.network.quantum.melange_connection
  :members:
  :undoc-members:
  :show-inheritance:
