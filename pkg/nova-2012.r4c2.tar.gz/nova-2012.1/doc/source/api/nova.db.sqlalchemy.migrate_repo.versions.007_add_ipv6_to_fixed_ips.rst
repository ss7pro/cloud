The :mod:`nova.db.sqlalchemy.migrate_repo.versions.007_add_ipv6_to_fixed_ips` Module
=====================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.007_add_ipv6_to_fixed_ips
  :members:
  :undoc-members:
  :show-inheritance:
