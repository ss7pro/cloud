The :mod:`nova.api.openstack.compute.contrib.cloudpipe` Module
===============================================================

.. automodule:: nova.api.openstack.compute.contrib.cloudpipe
  :members:
  :undoc-members:
  :show-inheritance:
