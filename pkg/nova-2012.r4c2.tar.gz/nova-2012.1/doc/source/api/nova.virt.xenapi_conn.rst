The :mod:`nova.virt.xenapi_conn` Module
========================================

.. automodule:: nova.virt.xenapi_conn
  :members:
  :undoc-members:
  :show-inheritance:
