The :mod:`nova.db.sqlalchemy.migrate_repo.versions.024_add_block_device_mapping` Module
========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.024_add_block_device_mapping
  :members:
  :undoc-members:
  :show-inheritance:
