The :mod:`nova.db.sqlalchemy.migrate_repo.versions.063_add_instance_faults_table` Module
=========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.063_add_instance_faults_table
  :members:
  :undoc-members:
  :show-inheritance:
