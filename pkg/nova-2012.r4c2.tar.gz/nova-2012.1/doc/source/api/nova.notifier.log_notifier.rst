The :mod:`nova.notifier.log_notifier` Module
=============================================

.. automodule:: nova.notifier.log_notifier
  :members:
  :undoc-members:
  :show-inheritance:
