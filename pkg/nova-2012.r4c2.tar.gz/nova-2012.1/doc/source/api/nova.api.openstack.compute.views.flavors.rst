The :mod:`nova.api.openstack.compute.views.flavors` Module
===========================================================

.. automodule:: nova.api.openstack.compute.views.flavors
  :members:
  :undoc-members:
  :show-inheritance:
