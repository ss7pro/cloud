The :mod:`nova.api.openstack.compute.contrib.consoles` Module
==============================================================

.. automodule:: nova.api.openstack.compute.contrib.consoles
  :members:
  :undoc-members:
  :show-inheritance:
