The :mod:`nova.virt.baremetal.proxy` Module
============================================

.. automodule:: nova.virt.baremetal.proxy
  :members:
  :undoc-members:
  :show-inheritance:
