The :mod:`nova.rootwrap.volume` Module
=======================================

.. automodule:: nova.rootwrap.volume
  :members:
  :undoc-members:
  :show-inheritance:
