The :mod:`nova.api.openstack.compute.contrib.certificates` Module
==================================================================

.. automodule:: nova.api.openstack.compute.contrib.certificates
  :members:
  :undoc-members:
  :show-inheritance:
