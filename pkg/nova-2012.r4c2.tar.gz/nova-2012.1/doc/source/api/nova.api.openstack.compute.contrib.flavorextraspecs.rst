The :mod:`nova.api.openstack.compute.contrib.flavorextraspecs` Module
======================================================================

.. automodule:: nova.api.openstack.compute.contrib.flavorextraspecs
  :members:
  :undoc-members:
  :show-inheritance:
