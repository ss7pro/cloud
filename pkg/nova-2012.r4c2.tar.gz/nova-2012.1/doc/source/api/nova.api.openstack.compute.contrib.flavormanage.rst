The :mod:`nova.api.openstack.compute.contrib.flavormanage` Module
==================================================================

.. automodule:: nova.api.openstack.compute.contrib.flavormanage
  :members:
  :undoc-members:
  :show-inheritance:
