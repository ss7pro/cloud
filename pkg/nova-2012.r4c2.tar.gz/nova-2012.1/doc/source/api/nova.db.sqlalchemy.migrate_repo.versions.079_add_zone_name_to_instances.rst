The :mod:`nova.db.sqlalchemy.migrate_repo.versions.079_add_zone_name_to_instances` Module
==========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.079_add_zone_name_to_instances
  :members:
  :undoc-members:
  :show-inheritance:
