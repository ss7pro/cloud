The :mod:`nova.db.sqlalchemy.migrate_repo.versions.006_add_provider_data_to_volumes` Module
============================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.006_add_provider_data_to_volumes
  :members:
  :undoc-members:
  :show-inheritance:
