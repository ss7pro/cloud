The :mod:`nova.db.api` Module
==============================

.. automodule:: nova.db.api
  :members:
  :undoc-members:
  :show-inheritance:
