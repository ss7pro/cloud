The :mod:`nova.scheduler.api` Module
=====================================

.. automodule:: nova.scheduler.api
  :members:
  :undoc-members:
  :show-inheritance:
