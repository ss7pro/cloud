The :mod:`nova.api.openstack.compute.contrib.scheduler_hints` Module
=====================================================================

.. automodule:: nova.api.openstack.compute.contrib.scheduler_hints
  :members:
  :undoc-members:
  :show-inheritance:
