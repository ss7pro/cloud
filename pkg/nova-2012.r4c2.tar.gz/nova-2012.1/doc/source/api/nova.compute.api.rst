The :mod:`nova.compute.api` Module
===================================

.. automodule:: nova.compute.api
  :members:
  :undoc-members:
  :show-inheritance:
