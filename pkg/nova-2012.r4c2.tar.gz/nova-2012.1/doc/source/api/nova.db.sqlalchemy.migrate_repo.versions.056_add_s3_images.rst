The :mod:`nova.db.sqlalchemy.migrate_repo.versions.056_add_s3_images` Module
=============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.056_add_s3_images
  :members:
  :undoc-members:
  :show-inheritance:
