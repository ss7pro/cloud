The :mod:`nova.network.quantum.fake_client` Module
===================================================

.. automodule:: nova.network.quantum.fake_client
  :members:
  :undoc-members:
  :show-inheritance:
