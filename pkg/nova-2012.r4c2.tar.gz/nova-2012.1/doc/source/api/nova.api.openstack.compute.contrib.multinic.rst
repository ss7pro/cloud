The :mod:`nova.api.openstack.compute.contrib.multinic` Module
==============================================================

.. automodule:: nova.api.openstack.compute.contrib.multinic
  :members:
  :undoc-members:
  :show-inheritance:
