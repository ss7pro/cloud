The :mod:`nova.db.sqlalchemy.migrate_repo.versions.038_add_uuid_to_virtual_interfaces` Module
==============================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.038_add_uuid_to_virtual_interfaces
  :members:
  :undoc-members:
  :show-inheritance:
