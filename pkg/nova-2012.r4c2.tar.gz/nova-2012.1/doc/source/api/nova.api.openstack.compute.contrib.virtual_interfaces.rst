The :mod:`nova.api.openstack.compute.contrib.virtual_interfaces` Module
========================================================================

.. automodule:: nova.api.openstack.compute.contrib.virtual_interfaces
  :members:
  :undoc-members:
  :show-inheritance:
