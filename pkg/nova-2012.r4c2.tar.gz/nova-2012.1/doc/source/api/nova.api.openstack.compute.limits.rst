The :mod:`nova.api.openstack.compute.limits` Module
====================================================

.. automodule:: nova.api.openstack.compute.limits
  :members:
  :undoc-members:
  :show-inheritance:
