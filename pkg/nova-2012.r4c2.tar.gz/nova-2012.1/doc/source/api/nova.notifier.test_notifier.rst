The :mod:`nova.notifier.test_notifier` Module
==============================================

.. automodule:: nova.notifier.test_notifier
  :members:
  :undoc-members:
  :show-inheritance:
