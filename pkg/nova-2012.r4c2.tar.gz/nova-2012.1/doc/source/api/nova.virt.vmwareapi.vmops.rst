The :mod:`nova.virt.vmwareapi.vmops` Module
============================================

.. automodule:: nova.virt.vmwareapi.vmops
  :members:
  :undoc-members:
  :show-inheritance:
