The :mod:`nova.api.manager` Module
===================================

.. automodule:: nova.api.manager
  :members:
  :undoc-members:
  :show-inheritance:
