The :mod:`nova.compute.manager` Module
=======================================

.. automodule:: nova.compute.manager
  :members:
  :undoc-members:
  :show-inheritance:
