The :mod:`nova.db.sqlalchemy.migrate_repo.versions.082_zone_to_cell` Module
============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.082_zone_to_cell
  :members:
  :undoc-members:
  :show-inheritance:
