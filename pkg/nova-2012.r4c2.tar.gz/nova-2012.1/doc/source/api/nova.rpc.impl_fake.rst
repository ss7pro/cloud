The :mod:`nova.rpc.impl_fake` Module
=====================================

.. automodule:: nova.rpc.impl_fake
  :members:
  :undoc-members:
  :show-inheritance:
