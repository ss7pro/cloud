The :mod:`nova.notifier.rabbit_notifier` Module
================================================

.. automodule:: nova.notifier.rabbit_notifier
  :members:
  :undoc-members:
  :show-inheritance:
