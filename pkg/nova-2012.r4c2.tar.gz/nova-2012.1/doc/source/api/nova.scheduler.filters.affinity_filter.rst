The :mod:`nova.scheduler.filters.affinity_filter` Module
=========================================================

.. automodule:: nova.scheduler.filters.affinity_filter
  :members:
  :undoc-members:
  :show-inheritance:
