The :mod:`nova.db.sqlalchemy.migrate_repo.versions.020_add_snapshot_id_to_volumes` Module
==========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.020_add_snapshot_id_to_volumes
  :members:
  :undoc-members:
  :show-inheritance:
