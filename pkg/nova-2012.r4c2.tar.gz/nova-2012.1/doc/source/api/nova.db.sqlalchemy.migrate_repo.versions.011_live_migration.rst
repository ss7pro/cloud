The :mod:`nova.db.sqlalchemy.migrate_repo.versions.011_live_migration` Module
==============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.011_live_migration
  :members:
  :undoc-members:
  :show-inheritance:
