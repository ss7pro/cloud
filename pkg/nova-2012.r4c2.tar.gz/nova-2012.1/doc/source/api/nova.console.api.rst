The :mod:`nova.console.api` Module
===================================

.. automodule:: nova.console.api
  :members:
  :undoc-members:
  :show-inheritance:
