The :mod:`nova.db.sqlalchemy.migrate_repo.versions.072_add_dns_table` Module
=============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.072_add_dns_table
  :members:
  :undoc-members:
  :show-inheritance:
