The :mod:`nova.virt.xenapi.volumeops` Module
=============================================

.. automodule:: nova.virt.xenapi.volumeops
  :members:
  :undoc-members:
  :show-inheritance:
