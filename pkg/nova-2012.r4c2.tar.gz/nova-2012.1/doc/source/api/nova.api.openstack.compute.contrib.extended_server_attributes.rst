The :mod:`nova.api.openstack.compute.contrib.extended_server_attributes` Module
================================================================================

.. automodule:: nova.api.openstack.compute.contrib.extended_server_attributes
  :members:
  :undoc-members:
  :show-inheritance:
