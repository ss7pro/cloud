The :mod:`nova.db.sqlalchemy.migrate_repo.versions.015_add_auto_assign_to_floating_ips` Module
===============================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.015_add_auto_assign_to_floating_ips
  :members:
  :undoc-members:
  :show-inheritance:
