The :mod:`nova.rpc.impl_carrot` Module
=======================================

.. automodule:: nova.rpc.impl_carrot
  :members:
  :undoc-members:
  :show-inheritance:
