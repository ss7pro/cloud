The :mod:`nova.db.sqlalchemy.migrate_repo.versions.021_rename_image_ids` Module
================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.021_rename_image_ids
  :members:
  :undoc-members:
  :show-inheritance:
