The :mod:`nova.api.openstack.compute.views.addresses` Module
=============================================================

.. automodule:: nova.api.openstack.compute.views.addresses
  :members:
  :undoc-members:
  :show-inheritance:
