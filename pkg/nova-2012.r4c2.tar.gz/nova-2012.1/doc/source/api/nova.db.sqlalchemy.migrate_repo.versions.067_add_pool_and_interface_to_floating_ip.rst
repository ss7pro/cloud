The :mod:`nova.db.sqlalchemy.migrate_repo.versions.067_add_pool_and_interface_to_floating_ip` Module
=====================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.067_add_pool_and_interface_to_floating_ip
  :members:
  :undoc-members:
  :show-inheritance:
