The :mod:`nova.auth.manager` Module
====================================

.. automodule:: nova.auth.manager
  :members:
  :undoc-members:
  :show-inheritance:
