The :mod:`nova.rpc.impl_kombu` Module
======================================

.. automodule:: nova.rpc.impl_kombu
  :members:
  :undoc-members:
  :show-inheritance:
