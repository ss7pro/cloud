The :mod:`nova.db.sqlalchemy.migrate_repo.versions.009_add_instance_migrations` Module
=======================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.009_add_instance_migrations
  :members:
  :undoc-members:
  :show-inheritance:
