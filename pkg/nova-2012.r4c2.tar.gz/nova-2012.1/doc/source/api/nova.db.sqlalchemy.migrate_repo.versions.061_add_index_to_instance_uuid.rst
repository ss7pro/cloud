The :mod:`nova.db.sqlalchemy.migrate_repo.versions.061_add_index_to_instance_uuid` Module
==========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.061_add_index_to_instance_uuid
  :members:
  :undoc-members:
  :show-inheritance:
