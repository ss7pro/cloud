The :mod:`nova.volume.nexenta.jsonrpc` Module
==============================================

.. automodule:: nova.volume.nexenta.jsonrpc
  :members:
  :undoc-members:
  :show-inheritance:
