The :mod:`nova.image.fake` Module
==================================

.. automodule:: nova.image.fake
  :members:
  :undoc-members:
  :show-inheritance:
