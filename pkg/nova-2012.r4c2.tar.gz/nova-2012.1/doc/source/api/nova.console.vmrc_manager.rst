The :mod:`nova.console.vmrc_manager` Module
============================================

.. automodule:: nova.console.vmrc_manager
  :members:
  :undoc-members:
  :show-inheritance:
