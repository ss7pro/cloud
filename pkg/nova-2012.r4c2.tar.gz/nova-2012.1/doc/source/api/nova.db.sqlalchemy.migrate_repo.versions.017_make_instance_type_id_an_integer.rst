The :mod:`nova.db.sqlalchemy.migrate_repo.versions.017_make_instance_type_id_an_integer` Module
================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.017_make_instance_type_id_an_integer
  :members:
  :undoc-members:
  :show-inheritance:
