The :mod:`nova.db.sqlalchemy.migrate_repo.versions.048_add_zone_name` Module
=============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.048_add_zone_name
  :members:
  :undoc-members:
  :show-inheritance:
