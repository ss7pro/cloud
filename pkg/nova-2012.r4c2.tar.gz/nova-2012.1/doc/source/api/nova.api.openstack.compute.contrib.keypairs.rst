The :mod:`nova.api.openstack.compute.contrib.keypairs` Module
==============================================================

.. automodule:: nova.api.openstack.compute.contrib.keypairs
  :members:
  :undoc-members:
  :show-inheritance:
