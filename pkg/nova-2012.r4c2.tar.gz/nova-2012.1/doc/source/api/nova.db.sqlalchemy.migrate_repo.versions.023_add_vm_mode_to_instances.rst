The :mod:`nova.db.sqlalchemy.migrate_repo.versions.023_add_vm_mode_to_instances` Module
========================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.023_add_vm_mode_to_instances
  :members:
  :undoc-members:
  :show-inheritance:
