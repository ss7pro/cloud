The :mod:`nova.consoleauth.manager` Module
===========================================

.. automodule:: nova.consoleauth.manager
  :members:
  :undoc-members:
  :show-inheritance:
