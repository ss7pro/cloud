The :mod:`nova.db.sqlalchemy.migrate_repo.versions.014_add_instance_type_id_to_instances` Module
=================================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.014_add_instance_type_id_to_instances
  :members:
  :undoc-members:
  :show-inheritance:
