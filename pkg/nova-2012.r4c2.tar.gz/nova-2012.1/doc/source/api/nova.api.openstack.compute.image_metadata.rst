The :mod:`nova.api.openstack.compute.image_metadata` Module
============================================================

.. automodule:: nova.api.openstack.compute.image_metadata
  :members:
  :undoc-members:
  :show-inheritance:
