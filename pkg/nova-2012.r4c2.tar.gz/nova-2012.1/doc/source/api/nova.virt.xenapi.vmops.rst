The :mod:`nova.virt.xenapi.vmops` Module
=========================================

.. automodule:: nova.virt.xenapi.vmops
  :members:
  :undoc-members:
  :show-inheritance:
