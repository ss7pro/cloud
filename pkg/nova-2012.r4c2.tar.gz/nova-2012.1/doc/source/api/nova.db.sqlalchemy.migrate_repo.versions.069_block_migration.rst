The :mod:`nova.db.sqlalchemy.migrate_repo.versions.069_block_migration` Module
===============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.069_block_migration
  :members:
  :undoc-members:
  :show-inheritance:
