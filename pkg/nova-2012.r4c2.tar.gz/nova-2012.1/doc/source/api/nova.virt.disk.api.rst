The :mod:`nova.virt.disk.api` Module
=====================================

.. automodule:: nova.virt.disk.api
  :members:
  :undoc-members:
  :show-inheritance:
