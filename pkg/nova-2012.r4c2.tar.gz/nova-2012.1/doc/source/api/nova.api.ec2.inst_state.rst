The :mod:`nova.api.ec2.inst_state` Module
==========================================

.. automodule:: nova.api.ec2.inst_state
  :members:
  :undoc-members:
  :show-inheritance:
