The :mod:`nova.scheduler.chance` Module
========================================

.. automodule:: nova.scheduler.chance
  :members:
  :undoc-members:
  :show-inheritance:
