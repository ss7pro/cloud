The :mod:`nova.rootwrap.compute` Module
========================================

.. automodule:: nova.rootwrap.compute
  :members:
  :undoc-members:
  :show-inheritance:
