The :mod:`nova.db.sqlalchemy.migrate_repo.versions.044_update_instance_states` Module
======================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.044_update_instance_states
  :members:
  :undoc-members:
  :show-inheritance:
