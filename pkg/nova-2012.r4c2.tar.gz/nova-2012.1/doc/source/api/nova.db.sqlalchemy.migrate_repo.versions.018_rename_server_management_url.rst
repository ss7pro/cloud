The :mod:`nova.db.sqlalchemy.migrate_repo.versions.018_rename_server_management_url` Module
============================================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.018_rename_server_management_url
  :members:
  :undoc-members:
  :show-inheritance:
