The :mod:`nova.api.openstack.compute.contrib.rescue` Module
============================================================

.. automodule:: nova.api.openstack.compute.contrib.rescue
  :members:
  :undoc-members:
  :show-inheritance:
