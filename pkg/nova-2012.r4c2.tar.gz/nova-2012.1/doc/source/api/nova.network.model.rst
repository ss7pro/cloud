The :mod:`nova.network.model` Module
=====================================

.. automodule:: nova.network.model
  :members:
  :undoc-members:
  :show-inheritance:
