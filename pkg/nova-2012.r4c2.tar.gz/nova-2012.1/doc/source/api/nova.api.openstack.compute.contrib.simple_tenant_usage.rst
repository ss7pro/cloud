The :mod:`nova.api.openstack.compute.contrib.simple_tenant_usage` Module
=========================================================================

.. automodule:: nova.api.openstack.compute.contrib.simple_tenant_usage
  :members:
  :undoc-members:
  :show-inheritance:
