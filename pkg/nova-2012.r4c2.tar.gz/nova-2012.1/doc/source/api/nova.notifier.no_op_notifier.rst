The :mod:`nova.notifier.no_op_notifier` Module
===============================================

.. automodule:: nova.notifier.no_op_notifier
  :members:
  :undoc-members:
  :show-inheritance:
