The :mod:`nova.api.openstack.compute.contrib.floating_ip_pools` Module
=======================================================================

.. automodule:: nova.api.openstack.compute.contrib.floating_ip_pools
  :members:
  :undoc-members:
  :show-inheritance:
