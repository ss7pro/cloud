The :mod:`nova.rpc.amqp` Module
================================

.. automodule:: nova.rpc.amqp
  :members:
  :undoc-members:
  :show-inheritance:
