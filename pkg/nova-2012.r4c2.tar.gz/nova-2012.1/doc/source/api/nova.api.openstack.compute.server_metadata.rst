The :mod:`nova.api.openstack.compute.server_metadata` Module
=============================================================

.. automodule:: nova.api.openstack.compute.server_metadata
  :members:
  :undoc-members:
  :show-inheritance:
