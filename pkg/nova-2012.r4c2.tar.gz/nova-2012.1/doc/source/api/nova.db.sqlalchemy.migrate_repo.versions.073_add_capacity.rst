The :mod:`nova.db.sqlalchemy.migrate_repo.versions.073_add_capacity` Module
============================================================================

.. automodule:: nova.db.sqlalchemy.migrate_repo.versions.073_add_capacity
  :members:
  :undoc-members:
  :show-inheritance:
