from distutils.core import setup
setup(name='novnc',
	version='0.01',
	packages=['novnc']
	)

