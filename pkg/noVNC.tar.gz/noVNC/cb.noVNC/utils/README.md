## WebSockets Proxy

wsproxy has become [websockify](https://github.com/kanaka/websockify).
A copy of the python version of websockify (named wsproxy.py) is kept
here for ease of use. The other versions of websockify (C, Node.js)
and the associated test programs have been moved to
[websockify](https://github.com/kanaka/websockify).

For more detailed description and usage information please refer to
the [websockify README](https://github.com/kanaka/websockify/blob/master/README.md).

