from distutils.core import setup

setup(name = "nova-novncproxy",
      version = "0.01",
      py_modules = ["python-novnc"],
      scripts = ["nova-novncproxy"],
     )

